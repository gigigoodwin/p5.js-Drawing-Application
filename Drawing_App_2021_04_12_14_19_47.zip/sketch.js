var r, g, b, v; 

var eraseButton;
var bigButton;
var smallButton;
var opacityButton; 


var x = 70;
var y = 300;
var w = 100;
var h = 50;
var k = 10;
var q = 10;


function setup() {
  createCanvas(600, 400);
  background(255);
  
  r = 0;
  g = 0;
  b = 0; 
  v = 255;
  
  eraseButton = createButton('erase');
  eraseButton.position(95,330);
  eraseButton.mousePressed(turnWhite)
  
  smallButton = createButton('stroke size +');
  smallButton.position(x+122,y+30);
  smallButton.mousePressed(increaseStroke);
  
  bigButton = createButton('stroke size -');
  bigButton.position(x+242, y+30);
  bigButton.mousePressed(decreaseStroke); 
  
  opacityButton = createButton('opacity');
  opacityButton.position(x+375,y+30);
  opacityButton.mousePressed(increaseOpacity);

}

function draw() {
  noFill();
  textSize(15);
  fill(0);
  text('In order to change the color, hit either:',5,20);
  text('the r key on your keyboard for the color red, the b key on your keyboard for the color blue,',5,40);
  text('or the g key on your keyboard for the color green!',5,60);
  text('To revert back to black, hit the n key!', 5,80);
  
  if(keyIsPressed){
        if(key == 'g'){
            r = 0;
            g = 255;
            b = 0; 
          
        }else if(key== 'b'){
            r = 0;
            g = 0;
            b = 255;
          
        }else if(key == 'r'){
            r = 255;
            g = 0;
            b = 0; 
          
         }else if(key == 'n'){
            r = 0;
            g = 0;
            b = 0; 
              
        }
  } 
  
  if (mouseIsPressed){
    fill(r,g,b,(v));
    noStroke();
    ellipse(mouseX,mouseY,k,q);
  }
  
}

function turnWhite(){
  r = 255;
  g = 255;
  b = 255;
  v = 255;
}

function increaseStroke(){
  k = k+1
  q = q+1
}

function decreaseStroke(){
  k = k-1
  q = q-1
}

function increaseOpacity(){
  v = v-5 
}
   